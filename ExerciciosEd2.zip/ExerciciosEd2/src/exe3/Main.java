package exe3;

import java.util.Scanner;

import util.Conversao;

public class Main {

	public static void main(String[] args) {
		
		int opcao;
		String chaves;
		System.out.println("Escolha o metodo: 1-Metodo da Divisao "
							+ "2-Metodo da Dobra "
							+ "3-Metodo da Multiplicaçao");
		
		Scanner teclado1 = new Scanner(System.in);
		Scanner teclado2 = new Scanner(System.in);
		opcao = teclado1.nextInt();
		
		System.out.println("Digite as chaves separadas por espaco:");
		chaves = teclado2.nextLine();
		
		String[] chavesString = chaves.split(" ");
		int[] chavesInt = Conversao.charInt(chavesString);
		
		TabelaHash t1 = new TabelaHash(3);
		
		int i=0;
		switch (opcao) 
		{
			case 1:
				while(i < chavesInt.length)
				{
					//crio objeto do tipo hash(chave e valor) por enquanto do uso a chave
					Hash hash = new Hash(chavesInt[i]); // Hash possui dois construtores 1 somente com a chave
					t1.divisao(hash);					// e outro  com chave e valor
					i++;
				}
				
				t1.imprimirTabela();
				break;
				
			case 2:
				while(i < chavesInt.length)
				{
					
					Hash hash = new Hash(chavesInt[i]);
					//t1.dobra(hash);
					i++;
				}
			
				break;
			case 3:
				while(i<chaves.length())
				{
					
					Hash hash = new Hash(chavesInt[i]);
					//t1.multiplicacao(hash);
					i++;
				}
	
				break;

			default:
				break;
		}
		
	}
}
