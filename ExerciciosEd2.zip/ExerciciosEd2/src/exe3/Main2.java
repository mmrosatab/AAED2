package exe3;

import javax.naming.SizeLimitExceededException;

public class Main2
{	
	public static void main(String[] args) 
	{
		byte t = 1;
		byte t1 = (byte) (t << 5);
		//00000001
		//00010000
		System.out.println(t1);
	}
}
