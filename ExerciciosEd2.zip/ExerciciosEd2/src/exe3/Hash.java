package exe3;

public class Hash 
{	
	private int chave;
	private int valor;
	
	public Hash(int chave, int valor) 
	{
		this.chave = chave;
		this.valor = valor;
	}
	
	public Hash(int chave) 
	{
		this.chave = chave;
	}
	
	public int getChave() 
	{
		return chave;
	}
	
	public void setChave(int chave) 
	{
		this.chave = chave;
	}
	
	public int getValor() 
	{
		return valor;
	}
	
	public void setValor(int valor) 
	{
		this.valor = valor;
	}

}
