package exe3;


import java.util.ArrayList;
import java.util.List;

public class TabelaHash
{
	
	private List<List<Hash>> tabela = new ArrayList<List<Hash>>();
	private int m; //dimensao da tabela
	
	public TabelaHash(int m)
	{
		this.m = m;
		
		for (int i = 0; i < m; i++) 
		{
			List<Hash> lista = new ArrayList();
			tabela.add(lista);
		}
	}

	public List<List<Hash>> getTabela() {
		return tabela;
	}
	
	/*
	public void setTabela(List<List<Hash>> tabela) {
		this.tabela = tabela;
	}
	*/
	
	public void divisao(Hash hash)
	{
		//metodo da divisao	
		int chave = hash.getChave();
		
		int i = chave % m;
		
		if(!chaveExiste(i,chave))
		{
			inserir(i,hash);
		}

	}
	
	public int dobra(int chave)
	{
		return 0;
	}
	
	public int multiplicacao(Hash hash)
	{
		char mul = (char)(hash.getChave() * hash.getChave());
		
		return 0;
	}
	
	public boolean chaveExiste(int indiceTabela,int chave)
	{	
		//crio uma referencia da lista que esta na tabela
		List lista = tabela.get(indiceTabela);
							
		for (int j = 0; j < lista.size(); j++) 
		{
				if(lista.get(j).equals(chave))
				{ 
						//chave já existe
						System.out.println("Chave:  "+chave+" ja existe na tabela, nao vou inserir");
						return true;
				}
		}
				// chave nao existe 
				return false;
	}
		
	public void inserir(int indiceTabela,Hash hash)
	{
			int chave = hash.getChave();
			//crio uma referencia da lista que esta na tabela
			List lista = tabela.get(indiceTabela);
			
			colisao(lista,chave);
			
			//adiciono chave na lista	
			System.out.println("Inserindo a chave:  "+chave+" no indice:  "+indiceTabela);
			lista.add(hash);
		
	}
	
	public void colisao(List lista,int chave)
	{
		if(!lista.isEmpty())
		{
			System.out.println("Ocorreu colisao para a chave:  "+chave);
		}
	}
	
	public void imprimirTabela()
	{
		System.out.println();
		System.out.println("Imprimindo tabela hash final:");
		
		for (int i = 0; i < tabela.size(); i++) 
		{
			System.out.println("elementos da posicao "+i+" da tabela:");
			for (int j = 0; j < tabela.get(i).size(); j++) 
			{
				if(!tabela.get(i).isEmpty())
				{	
					System.out.println(tabela.get(i).get(j).getChave());
					
				}
				
			}
			
			
		}
		
	}
}
