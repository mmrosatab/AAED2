package exe2;

import java.io.IOException;
import java.io.RandomAccessFile;

import util.Conversao;

public class Arquivo 
{

	public static void escrever(RandomAccessFile arquivo,int matricula,String nome,int ano,int semestre,int codigo_curso) throws IOException 
	{
		
		// fazendo tratamento da string
		byte[] arrayNome = Conversao.stringByte(nome);
		
		byte []arrayTamNome = Conversao.intToByteArray2(nome.length());
		byte []arrayMat = Conversao.intToByteArray2(matricula);
		byte []arrayAno = Conversao.intToByteArray2(ano);
		byte []arrayCod = Conversao.intToByteArray2(codigo_curso);
		byte []arraySem = Conversao.intToByteArray2(semestre);
				
		arquivo.write(arrayMat);
		arquivo.write(arrayTamNome);
		arquivo.write(arrayNome);
		arquivo.write(arrayAno);
		arquivo.write(arraySem);
		arquivo.write(arrayCod);
	
	
	}
}
