package exe2;

import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

import util.Conversao;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		// tive que usar 2 scanner's pq estavam dando problema na leitura do teclado
		Scanner teclado1 = new Scanner(System.in);
		Scanner teclado2 = new Scanner(System.in);
		RandomAccessFile arquivo = new RandomAccessFile("teste.bin","rw");

		
		System.out.println("Escolha a opçao desejada"+
							" 1 - Inserir registro,"+
							" 2 - Buscar registro,"+
							" 3 - Encerrar programa");
		
		int opcao = teclado1.nextInt();
		
		while(opcao != 3)
		{
			switch (opcao) 
			{
				case 1:
					
					//pegando dados via teclado
					System.out.println("Digite matricula:");
					int matricula = teclado1.nextInt();
					System.out.println("Digite nome:");
					String nome = teclado2.nextLine();
					System.out.println("Digite ano:");
					int ano = teclado1.nextInt();
					System.out.println("Digite semestre:");
					int semestre = teclado1.nextInt();
					System.out.println("Digite codigo_curso:");
					int codigo_curso = teclado1.nextInt();
							
					// caso ja exista registros no arquivo de outras execucoes
					// pulo a qtd de bytes para chegar no final do arquivo
					// e gravo os proximos registros a partir deste ponto
					if(arquivo.length()!= 0)
					{
						arquivo.seek(arquivo.length());
					}
					// escrevo no arquivo registro de usuario no arquivo binario 
					// ja colocando o tamanho da string nome entre a matricula e o nome
					exe2.Arquivo.escrever(arquivo,matricula, nome, ano, semestre, codigo_curso);

					
					break;
			
				case 2:
					
					int totBytes = 0;
					boolean acabou = false;
					int matArquivo;
					
					byte[] pegaInteiro = new byte[4];
				
					// rebobinando leitura arquivo
					arquivo.seek(0);
					//buscar registro
					System.out.println("Digite a matricula (chave):");
					int matricula1 = teclado2.nextInt();
					
					arquivo.read(pegaInteiro);
					matArquivo = Conversao.byteArrayToInt2(pegaInteiro);
					
					//System.out.println("Matricula arquivo: "+matArquivo);
					
					while(!acabou  && matArquivo != matricula1)
					{
						long teste = arquivo.getFilePointer();
						long tamanho = arquivo.length();
						System.out.println("TESTE FIM = "+teste);
		
						try 
						{
							arquivo.read(pegaInteiro);
							int tamString = Conversao.byteArrayToInt2(pegaInteiro);
							 
							// string + 4 bytes semestre + 4 bytes ano + 4 bytes cod_curso
							// + 4 bytes do matricula + int tam string  
							totBytes = totBytes + tamString*2 + 20; // total de bytes para pular para o prox registro
							
							//ando para proximo registro
							arquivo.seek(totBytes);
							
							arquivo.read(pegaInteiro);
							matArquivo = Conversao.byteArrayToInt2(pegaInteiro);
							
						} catch (Exception e) 
						{
							acabou = true;
						} 
						
						
					}
					
					
					//achou matricula pega os proximos atributos e imprimir
					if(matArquivo == matricula1)
					{
						System.out.println("Achei o registro");
						System.out.println();
						
						System.out.println("Matricula :"+matArquivo);
						arquivo.read(pegaInteiro);
						int tamString = Conversao.byteArrayToInt2(pegaInteiro);
						
						byte []arrayNome = new byte[tamString*2];
						arquivo.read(arrayNome);
						String nomeAluno = new String(arrayNome,"UTF-16");
						
						arquivo.read(pegaInteiro);
						int anoC = Conversao.byteArrayToInt2(pegaInteiro);
						
						arquivo.read(pegaInteiro);
						int sem = Conversao.byteArrayToInt2(pegaInteiro);
						
						arquivo.read(pegaInteiro);
						int curso = Conversao.byteArrayToInt2(pegaInteiro);
						
						System.out.println("Nome:"+nomeAluno);
						System.out.println("Ano: "+anoC);
						System.out.println("Semestre: "+sem);
						System.out.println("Codigo curso: "+curso);
					
					}else
					{
						System.out.println("Nao achei nenhum registro com essa matricula");
					}
					
					
					/*
					 * fazendo teste lendo registro por registro
					 * 
					int tamString = arquivo.readInt();
					System.out.println("tamanho string: "+tamString);
					
					totBytes = totBytes + tamString*2 + 20; // total de bytes para pular para o prox registro
					
					System.out.println("tam reg:"+totBytes);
					
					//ando para proximo registro
					arquivo.seek(totBytes);
					
					matArquivo = arquivo.readInt();
					System.out.println("proxima matricula eh: "+matArquivo);
					
					tamString = arquivo.readInt();
					System.out.println("tamanho string: "+tamString);
					
					totBytes = totBytes + tamString*2 + 20; // total de bytes para pular para o prox registro
					
					System.out.println("tam reg:"+totBytes);
					
					//ando para proximo registro
					arquivo.seek(totBytes);
					matArquivo = arquivo.readInt();
					System.out.println("proxima matricula eh: "+matArquivo);
					
					tamString = arquivo.readInt();
					System.out.println("tamanho string: "+tamString);
					
					*/
					
					break;
				default:
					System.out.println("opcao invalida");
					break;
			}
			
			
			System.out.println("Escolha a opçao desejada"+
							" 1 - Inserir registro"+
							" 2 - Buscar registro"+
							" 3 - Encerrar programa");
		
			opcao = teclado1.nextInt();
		
		}
		
		arquivo.close();
		System.out.println("Programa encerrado!");
	}

}
