package exe1;

import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Arquivo 
{
	
	public int posicao(String nomeArquivo,String substring) 
	{
		int deslocamento = 0; // variavel que marcara a quantidade de bytes ate determinada palavra
		
		try {
			
			RandomAccessFile arq = new RandomAccessFile(nomeArquivo+".bin","rw");
			char[] sub = substring.toCharArray();
			
			int i=0,j=0;
			char c = arq.readChar();
			
			while(c!=-1)
			{
				//deslocamento++; //coloquei esse deslocamento l� embaixo
				
				if(c == sub[i]) // da pra trocar esse sub[i] para sub[0] tbm funciona
				{
					j = i+1;
					
					while(j<sub.length)
					{
						c = arq.readChar();
						
						if(sub[j] == c)
						{
							j++;
						}else
						{
							i = 0;
							deslocamento = deslocamento + j;	//alterei aqui coloquei deslocamento = deslocamanto + j
							break;								//quando tiver entrado no segundo while mas nao achei um caracter igual
																//deslocamento devera receber um acrescimo do que andou no junto com o vetor sub
							
						}
					}
					if(j == sub.length)
					{
						
						return deslocamento;
					}
					
				}else{
					
					c = arq.readChar();
					deslocamento++; 
					
				}
				
				//c = arq.readChar();	//alterei aqui coloquei isso dentro do else de cima
				//deslocamento++;
			}
			
			
		} catch (Exception e) 
		{
			// TODO: handle exception
		}
		
		System.out.println("sai do while nao achei a palavra");
		return -1;
	}
	
	
	
	// metodo que cria arquivo binario a partir no arquivo de texto
	// passando como par�metro nome do arquivo de texto
	public void criarBin(String nomeArquivo)
	{
		
		try 
		{
			String conteudo = new String(Files.readAllBytes(Paths.get(nomeArquivo+".txt")));
			
			// print de teste
			//System.out.println("Tamanho da String: "+conteudo.length());
			//System.out.println(conteudo);
			
			//fazendo convers�o para array de byte
			char[] arrayChar = conteudo.toCharArray();
			byte[] arrayByte = new byte[2*arrayChar.length];
			
			for (int i = 0; i < arrayChar.length; i++) 
			{
	            int posicao = i * 2;
	            arrayByte[posicao] = (byte) ((arrayChar[i]&0xFF00)>>8);
	            arrayByte[posicao+1] = (byte) ((arrayChar[i]&0x00FF));
			}
			
			RandomAccessFile arqDes = new RandomAccessFile(nomeArquivo+".bin","rw");
			//RandomAccessFile arqDes = new RandomAccessFile("arquivoBinario.bin","rw");
			arqDes.write(arrayByte);
			arqDes.close();
			
		} catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
			
		}
	
	}
	
	// metodo imprimi conteudo de arquivo txt
	public void imprimirArquivo(String nomeArquivo)
	{
		try {
			
			RandomAccessFile arq = new RandomAccessFile(nomeArquivo,"rw");
			char c = arq.readChar();
			
			while(c!=-1)
			{
				System.out.println(c);
				c = arq.readChar();
			}
			
			
		} catch (Exception e) 
		{
			// TODO: handle exception
		}
		
	}

}
