package exe1;

import java.io.IOException;

public class Main 
{

	public static void main(String[] args) throws IOException 
	{
		Arquivo a = new Arquivo();
		a.criarBin("arquivoTexto");
		System.out.println(a.posicao("arquivoTexto","ed2"));

	
	}

}
